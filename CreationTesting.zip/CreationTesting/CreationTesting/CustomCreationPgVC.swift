// this is the page view controller

import Foundation
import UIKit

class CustomCreationPageVC: UIPageViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

}
