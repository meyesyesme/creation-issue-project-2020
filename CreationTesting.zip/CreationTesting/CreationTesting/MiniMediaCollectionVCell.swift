//for the minimedia collectionview

import UIKit

class MiniMediaCollectionVCell: UICollectionViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    var baseView = UIView()
    
    var imageView = UIImageView()
    var representedAssetIdentifier: String? = nil

    override init(frame: CGRect) {
        super.init(frame: frame)

        baseView.frame = self.bounds
        baseView.backgroundColor = .purple

        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.frame = baseView.frame
        
        baseView.addSubview(imageView)
        self.addSubview(baseView)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        self.layer.borderWidth = 1
        self.layer.cornerRadius = 8
        
        let myColor = UIColor.black
        self.layer.borderColor = myColor.cgColor
    }
    
    var hasBeenSelected = false
    
    func selectedState() {
        let myColor = UIColor.red
        self.layer.borderColor = myColor.cgColor
        self.layer.borderWidth = 5
        
        hasBeenSelected = true
    }
    
    func unselectState() {
        let myColor = UIColor.white
        self.layer.borderColor = myColor.cgColor
        self.layer.borderWidth = 2
        
        hasBeenSelected = false
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
