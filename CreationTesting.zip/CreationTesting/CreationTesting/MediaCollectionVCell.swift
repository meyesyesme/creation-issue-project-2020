//for the device photos collecitonview

import UIKit
import Photos

class MediaCollectionVCell: UICollectionViewCell {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    var baseView = UIView()
    
    var customImageView = UIImageView()
    var representedAssetIdentifier: String? = nil

    var assetPH: PHAsset?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        baseView.frame = CGRect(x: 0, y: 0, width: self.contentView.frame.width, height: self.contentView.frame.height)
        
        customImageView.contentMode = .scaleAspectFill
        customImageView.clipsToBounds = true
        self.clipsToBounds = true

        baseView.addSubview(customImageView)
        self.addSubview(baseView)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        customImageView.frame = baseView.frame
        self.layer.borderWidth = 0.3
        
        let myColor = UIColor.gray
        self.layer.borderColor = myColor.cgColor
    }
    
    var hasBeenSelected = false
    
    func selectedState() {
        let myColor = UIColor.red
        self.layer.borderColor = myColor.cgColor
        self.layer.borderWidth = 3
        
        hasBeenSelected = true
    }
    
    func unselectState() {
        let myColor = UIColor.gray
        self.layer.borderColor = myColor.cgColor
        self.layer.borderWidth = 1

        hasBeenSelected = false
    }
    
    let durationLbl = UILabel()
    var myTimeDuration = TimeInterval()
    
    func addTimeDurationLbl(timeDuration: TimeInterval) {
        myTimeDuration = timeDuration
       
        baseView.addSubview(durationLbl)
        durationLbl.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            durationLbl.leadingAnchor.constraint(equalTo: baseView.leadingAnchor, constant: 5),
            durationLbl.trailingAnchor.constraint(equalTo: baseView.trailingAnchor, constant: -5),
            durationLbl.bottomAnchor.constraint(equalTo: baseView.bottomAnchor, constant: -5),
        ])

        durationLbl.font = UIFont(name: "Arial", size: 15)
        durationLbl.lineBreakMode = .byWordWrapping
        durationLbl.numberOfLines = 0
        
        durationLbl.textColor = UIColor.white
        
        durationLbl.layer.shadowColor = UIColor.black.cgColor
        durationLbl.layer.shadowRadius = 2.0
        durationLbl.layer.shadowOpacity = 0.25
        durationLbl.layer.shadowOffset = CGSize(width: 0, height: 0)
        durationLbl.layer.masksToBounds = false
        durationLbl.text = timeDuration.stringFromTimeInterval()
        
        durationLbl.isHidden = false
    }
    
    func resetCellUI() {
        durationLbl.isHidden = true
        unselectState()
        hasBeenSelected = false
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
