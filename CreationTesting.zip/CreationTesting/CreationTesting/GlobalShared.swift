//globalshareddata object

import Foundation
import UIKit

class GlobalSharedData: NSObject {
    
    static let shared = GlobalSharedData()
    
    var arrayOfCurrentCreateMedia = [InterimMediaObject]()
            
}

