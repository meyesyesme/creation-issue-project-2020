//general creationVC

import Foundation
import UIKit
import AVFoundation
import Photos

class CreationVC: UIViewController {
    
    var contentView = UIView()
    var currentViewControllerIndex = 0
    
    let topView = UIView()
    
    var miniPreviewCollectionView: UICollectionView!
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupContentView()
                
        setupMiniPreview()
        setupTopView()
        
        configurePgViewController()
        
    }
    
//    override func viewDidAppear(_ animated: Bool) {
//        super.viewDidAppear(animated)
//
//    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        
        miniPreviewCollectionView.collectionViewLayout.invalidateLayout()
    }

    var existingMediaVC1: ExistingMediaVC?
    
    var topViewHeightConstant: CGFloat = 45
    
    func setupTopView() {
        topView.translatesAutoresizingMaskIntoConstraints = false
        
        self.view.addSubview(topView)
        
        let safeArea = self.view.safeAreaLayoutGuide

        NSLayoutConstraint.activate([
            topView.heightAnchor.constraint(equalToConstant: topViewHeightConstant),
            topView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0),
            topView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 0),
            topView.topAnchor.constraint(equalTo: safeArea.topAnchor, constant: 0),
        ])
        topView.backgroundColor = UIColor.white.withAlphaComponent(1.0)
        topView.layoutIfNeeded()
        
        topView.addSubview(pageTitle)

        let frameForPgTitle = CGRect()
        pageTitle.frame = frameForPgTitle
        pageTitle.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            pageTitle.heightAnchor.constraint(equalToConstant: 30),
            pageTitle.widthAnchor.constraint(equalToConstant: 120),
            pageTitle.centerXAnchor.constraint(equalToSystemSpacingAfter: view.centerXAnchor, multiplier: 1),
            pageTitle.centerYAnchor.constraint(equalToSystemSpacingBelow: topView.centerYAnchor, multiplier: 1),
        ])
        
        pageTitle.textColor = .black
        pageTitle.textAlignment = .center
        pageTitle.font = UIFont(name: "Arial", size: 18)
        pageTitle.text = "Album"
        pageTitle.backgroundColor = .clear
        pageTitle.numberOfLines = 1
        pageTitle.lineBreakMode = .byWordWrapping
        pageTitle.sizeToFit()
        pageTitle.isUserInteractionEnabled = false
        
        pageTitle.layoutIfNeeded()
    }
    
    let pageTitle = UILabel()
    
    func setupContentView() {
        contentView.frame = CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height)
        self.view.addSubview(contentView)
    }
            
    var vcArray = [UIViewController]()
    var pageVC: CustomCreationPageVC?
    
    func configurePgViewController() {
        print("CustomCreationPageVC setup")
                                            
            let storyBoard = UIStoryboard(name: "Main", bundle: nil)
            let existingMediaVC = storyBoard.instantiateViewController(withIdentifier: "ExistingMediaVC")
                      
            vcArray.append(contentsOf: [existingMediaVC])
                                        
        existingMediaVC1 = existingMediaVC as? ExistingMediaVC
        existingMediaVC1!.parentCreationVC = self
        
        existingMediaVC1!.topViewHeightConstant = topViewHeightConstant
        
            guard let pageViewController = storyBoard.instantiateViewController(withIdentifier: String(describing: CustomCreationPageVC.self)) as? CustomCreationPageVC else {
               print("issue occured")
                return
            }
            
            pageViewController.delegate = self
            pageViewController.dataSource = self
            
            addChild(pageViewController)
            pageViewController.didMove(toParent: self)
            
            pageViewController.view.translatesAutoresizingMaskIntoConstraints = false
            contentView.addSubview(pageViewController.view)
            
            let views: [String: Any] = ["pageView": pageViewController.view]
            
            contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[pageView]-0-|", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views))
            contentView.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[pageView]-0-|", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views))
                        
            if let firstViewController = vcArray.first {
                pageViewController.setViewControllers([firstViewController], direction: .forward, animated: true, completion: nil)
            }
              
        pageVC = pageViewController
        
    }
    
    var miniPreviewView = UIView()
    
    func setupMiniPreview() {

        let layout2 = MiniPreviewFlowLayout(
            minimumInteritemSpacing: 0,
            minimumLineSpacing: 8,
            sectionInset: UIEdgeInsets(top: 0, left: 13, bottom: 0, right: 13)
        )
        layout2.scrollDirection = .horizontal
        
        let frameForPreviewClctnVC = CGRect()

        miniPreviewCollectionView = UICollectionView(frame: frameForPreviewClctnVC, collectionViewLayout: layout2)
        
        miniPreviewCollectionView.translatesAutoresizingMaskIntoConstraints = false
        miniPreviewView.translatesAutoresizingMaskIntoConstraints = false
        miniPreviewView.backgroundColor = UIColor.black.withAlphaComponent(1.0)
        miniPreviewCollectionView.backgroundColor = .clear

        miniPreviewCollectionView.register(MiniMediaCollectionVCell.self, forCellWithReuseIdentifier: "MiniCell")
        miniPreviewCollectionView.delegate = self
        miniPreviewCollectionView.dataSource = self
        miniPreviewCollectionView.alwaysBounceHorizontal = true
        miniPreviewCollectionView.showsHorizontalScrollIndicator = false
        
        self.view.addSubview(miniPreviewView)
            let safeArea = self.view.safeAreaLayoutGuide

            NSLayoutConstraint.activate([
                miniPreviewView.heightAnchor.constraint(equalToConstant: 65),
                miniPreviewView.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor, constant: 0),
                miniPreviewView.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor, constant: 0),
                miniPreviewView.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor, constant: 0),
            ])

        miniPreviewView.addSubview(miniPreviewCollectionView)

        NSLayoutConstraint.activate([
            miniPreviewCollectionView.leadingAnchor.constraint(equalTo: miniPreviewView.leadingAnchor, constant: 0),
            miniPreviewCollectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10),
            miniPreviewCollectionView.topAnchor.constraint(equalTo: miniPreviewView.topAnchor, constant: 0),
            miniPreviewCollectionView.bottomAnchor.constraint(equalTo: miniPreviewView.bottomAnchor, constant: 0),
        ])

    }
            
    private class var newFileUrl: URL? {

        let fileManager = FileManager()

        guard let documentsFolder = try? fileManager.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true) else {
            print("issue occured?")
            return nil
        }
        
        let randomNumber = arc4random_uniform(10000)
        let randomNumber2 = arc4random_uniform(10000)
        let newNum = (randomNumber*randomNumber2)/2
        
        let fileName = "Untitled \(newNum).MP4"

        let fileUrl = documentsFolder.appendingPathComponent(fileName)

        guard !fileManager.fileExists(atPath: fileUrl.path) else {
            print("file path already existed issue")
            return nil
        }
                    
        return fileUrl
    }
    
    func removeVideoFiles(url: URL) {
        let fileManager = FileManager.default
        
        do {
            try fileManager.removeItem(atPath: url.path)
            fileManager.fileExists(atPath: url.path)
        } catch {
            print("Could not clear temp folder: \(error)")
        }
        
    }


    
}

extension CreationVC: UIPageViewControllerDelegate, UIPageViewControllerDataSource {
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        print("pageViewController viewControllerBefore")

        guard let vcIndex = vcArray.index(of: viewController) else {print("issue occured vcindex"); return nil}
        
        let previousIndex = vcIndex - 1
        
        guard previousIndex >= 0 else {print("issue occured pt 2"); return nil}
        
        guard vcArray.count > previousIndex else {print("issue occured pt 3"); return nil}
        
        print(previousIndex, " previousIndex!")
        return vcArray[previousIndex]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        print(viewController, "<--viewController after")

        guard let vcIndex = vcArray.index(of: viewController) else {print("prnt ok ok"); return nil}
        print(vcIndex, "<--vcIndex what")

        let nextIndex = vcIndex + 1
        
        guard vcArray.count != nextIndex else {print("jghbdjhbgdf"); return nil}
         
        guard vcArray.count > nextIndex else {print("dogjngdsgdgddkgjdnkg"); return nil}

        print(nextIndex, "nextIndex!")

        return vcArray[nextIndex]
    }
        
    func pageViewController(_ pageViewController: UIPageViewController, willTransitionTo pendingViewControllers: [UIViewController]) {

    }
    
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {

    }
    
}


extension CreationVC: UICollectionViewDelegate, UICollectionViewDelegateFlowLayout, UICollectionViewDataSource {

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        if collectionView == self.existingMediaVC1!.existingMediaCollectionView {
            print("self.existingMediaCollectionView???")

                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CellCo", for: indexPath) as! MediaCollectionVCell

                // Get the asset. If nothing, return the cell.
            guard let asset = self.existingMediaVC1!.latestPhotoAssetsFetched?[indexPath.item] else {
                    return cell
                }

            // Here we bind the asset with the cell.
                cell.representedAssetIdentifier = asset.localIdentifier
            
            if self.existingMediaVC1!.hasBeenSelectedDict[indexPath.row] != true { //not selected
                //remove ui
                self.existingMediaVC1!.hasBeenSelectedDict[indexPath.row] = false
                cell.resetCellUI()

            } else { //selected
                //Keep design or add.
                cell.selectedState()

            }
            
            if asset.duration != 0.0 {
                //video
                cell.addTimeDurationLbl(timeDuration: asset.duration)
//                let cashManager = PHCachingImageManager()
                let option = PHImageRequestOptions()
                var thumbnail = UIImage()
                option.isSynchronous = false
                PHImageManager.default().requestImage(for: asset, targetSize: CGSize(width: 138, height: 138), contentMode: .aspectFill, options: option, resultHandler: {
                    (result, info)->Void in //og it was 138 138... mybe can keep it that way?

                    thumbnail = result!
                })
                cell.customImageView.image = thumbnail
        
            } else {
        
                //original solution does not fectch the edit in photos...
                //          let url = asset.getURL(completionHandler: { (url) in
                //              cell.customImageView.sd_setImage(with: url)
                //          })
                
                let cashManager = PHCachingImageManager()
                
                let options = PHImageRequestOptions()
                options.isNetworkAccessAllowed = true
                options.isSynchronous = true
                options.resizeMode = .exact
                let targetSize = CGSize(width:375, height:667)

//                PHImageManager.default().requestImage(for: asset, targetSize: targetSize, contentMode: PHImageContentMode.aspectFit, options: options) { (receivedImage, info) in
//
//                    if let formAnImage = receivedImage
//                    {
//                        //You will get image here..
//                    }
//                }
                var image = UIImage()

//                DispatchQueue.global(qos: .background).async {
                    PHImageManager.default().requestImage(for: asset, targetSize: CGSize(width: 375, height: 667), contentMode: .aspectFill, options: options, resultHandler: {
                        (result, info)->Void in
                        print("image = result!")
                        image = result!
                    })
//                }
                
//                let option = PHImageRequestOptions()
//                option.isSynchronous = false
////                option.deliveryMode = .highQualityFormat
//                PHImageManager.default().requestImage(for: asset, targetSize: CGSize(width: 138, height: 138), contentMode: .aspectFill, options: option, resultHandler: {
//                    (result, info)->Void in
//                    image = result!
//                })
                cell.customImageView.image = image
        
            }
            cell.assetPH = asset
            
            return cell

        } else if collectionView == self.miniPreviewCollectionView {
            print("collectionView == self.miniPreviewCollectionView")

            let createCell = collectionView.dequeueReusableCell(withReuseIdentifier: "MiniCell", for: indexPath) as! MiniMediaCollectionVCell

//            // Get the asset. If nothing, return the cell. //do we need this below?
//            guard let asset = self.latestPhotoAssetsFetched?[indexPath.item] else {
//
//                // add a not found or soethgn...
//                return cell
//            }
            print(indexPath.row, "-- indexPath.row??")

            createCell.imageView.image = GlobalSharedData.shared.arrayOfCurrentCreateMedia[indexPath.row].thumbnailImage ?? GlobalSharedData.shared.arrayOfCurrentCreateMedia[indexPath.row].image
            
            return createCell
        } else {
            preconditionFailure("Unknown collection view!")
        }
        
        }
    
        //MARK: CollectionView
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            print("numberOfItemsInSection???")

            if collectionView == self.existingMediaVC1!.existingMediaCollectionView {

                print(collectionView, "collectionView kjfdnkjfng???")

                return self.existingMediaVC1!.latestPhotoAssetsFetched!.count

            }  else if collectionView == self.miniPreviewCollectionView {
                print("self.miniPfdreviegddgdfgfdgwCollectionView???")
                return GlobalSharedData.shared.arrayOfCurrentCreateMedia.count
            } else {
                preconditionFailure("Unknown collection view!")
            }

        }

    
        func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
           print("didSelectItemAt???")

            print(indexPath, "<-- index path gratatata, collection --->", collectionView)
            
            if collectionView == self.existingMediaVC1!.existingMediaCollectionView {
                
                let cell = collectionView.cellForItem(at: indexPath) as? MediaCollectionVCell
                                            
                print(cell?.hasBeenSelected, "<-- cell?.isSelected??")
                                            
                if cell!.hasBeenSelected { //UNSELECT
                    cell?.unselectState()
                    self.existingMediaVC1!.hasBeenSelectedDict[indexPath.row] = false

                    var numFor4Loop = 0 //since it starts at 0..
                    print(GlobalSharedData.shared.arrayOfCurrentCreateMedia.count, "<-- selectedMediaArray.count... ???")
                    var itsThisNumToDelete: Int!
                    for item in GlobalSharedData.shared.arrayOfCurrentCreateMedia {
                        
                        if item.cellIndexPath?.row == indexPath.row {
                            print(numFor4Loop, "grande caca?")
                            itsThisNumToDelete = numFor4Loop
                        }
                        
                        numFor4Loop+=1
                    }
                    print(numFor4Loop, "<-- numFor4Loop FANCY!")
                    print(itsThisNumToDelete, "<-- itsThisNumToDelete FANCY!")

                    if !(itsThisNumToDelete < 0) { //a safety handle...
                        if GlobalSharedData.shared.arrayOfCurrentCreateMedia[itsThisNumToDelete].videoURL != nil {
                            removeVideoFiles(url: GlobalSharedData.shared.arrayOfCurrentCreateMedia[itsThisNumToDelete].videoURL!)
                        }
                        GlobalSharedData.shared.arrayOfCurrentCreateMedia.remove(at: itsThisNumToDelete)
                    }
                    self.miniPreviewCollectionView.reloadData()
                    
                } else { //SELECT
                        
                        cell?.selectedState()
                        self.existingMediaVC1!.hasBeenSelectedDict[indexPath.row] = true
                                                
                        let dateOfSelection = Date().timeIntervalSinceReferenceDate
                        
                        if cell?.durationLbl.isHidden == true {
                            //here do the new minicell:
                            let newUserTakenImage = InterimMediaObject(image: (cell?.customImageView.image)!, phAsset: (cell?.assetPH)!, cellIndexPath: indexPath, timeStamp: dateOfSelection)
                            GlobalSharedData.shared.arrayOfCurrentCreateMedia.append(newUserTakenImage)

                        } else { //tis video
                            
                            let newUserTakenVideo = InterimMediaObject(phAsset: (cell?.assetPH)!, thumbnailImg: (cell?.customImageView.image)!, cellIndexPath: indexPath, timeStamp: dateOfSelection)
                            
                            let resource = PHAssetResource.assetResources(for: (cell?.assetPH)!)
                            print(resource, "<-- resource?/ does ti work?")
                            
                            let phResourceManager = PHAssetResourceManager()
                            let resourceRequestOptions = PHAssetResourceRequestOptions()
                            
                            let newURL = CreationVC.newFileUrl
                            
                            var newUserTakenObjToPassToVideoTrimIfNeeded = newUserTakenVideo
                            
                            phResourceManager.writeData(for: resource.first!, toFile: newURL!, options: resourceRequestOptions) { (error) in
                                if error != nil {
                                    print("not c67omplted error?")
                                } else {
                                    print("woah completedd 345?")
                                    
                                    newUserTakenVideo.videoURL = newURL
                                }
                            }
                            
                            //here do the new minicell:
                            GlobalSharedData.shared.arrayOfCurrentCreateMedia.append(newUserTakenVideo)
                            
                        }
                        
                        self.miniPreviewCollectionView.reloadData()

                }

            }  else if collectionView == self.miniPreviewCollectionView {
                print("self.miniPreviewCollectionView???")
            }
            
        }
    
    func loadVideoData(phAsset: PHAsset, completion: @escaping (Data?)->()) {
        guard phAsset.mediaType == .video else {
            return completion(nil)
        }
        let options = PHVideoRequestOptions()
        options.isNetworkAccessAllowed = true
        options.deliveryMode = .highQualityFormat
        PHCachingImageManager().requestAVAsset(forVideo: phAsset, options: options) { (avAsset, _, _) in
            guard let avUrlAsset = avAsset as? AVURLAsset else {
                return
            }
            var videoData: Data?
            do {
                videoData = try Data(contentsOf: avUrlAsset.url)
            } catch {
                fatalError()
            }
            DispatchQueue.main.async {
                completion(videoData)
            }
        }
    }
    
    var tempVideoFileUrl: URL {
        return FileManager.default.temporaryDirectory.appendingPathComponent("my_video_name")
    }

    func storeVideoToTemporaryFolder(videoData: Data) {
        guard !FileManager.default.fileExists(atPath: tempVideoFileUrl.path) else {
            return
        }
        do {
            try videoData.write(to: tempVideoFileUrl)
        }
        catch {
            fatalError()
        }
    }

    func loadVideoFromTemporaryFolder() -> Data? {
        if let data = try? Data(contentsOf: tempVideoFileUrl) {
            return data
        }
        return nil
    }
                
    func urlOfCurrentlyPlayingInPlayer(player : AVPlayer) -> URL? {
        return ((player.currentItem?.asset) as? AVURLAsset)?.url
    }
    
}
