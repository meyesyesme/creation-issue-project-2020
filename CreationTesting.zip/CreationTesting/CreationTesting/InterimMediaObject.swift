//media object

import Foundation
import UIKit
import Photos

class InterimMediaObject: NSObject {
    
    //This is the media object for uploading and any other short term reasons.
    var image: UIImage?
    var videoURL: URL?
    var postTimeStamp: Double?
    var userID: String?
    var timeStamp: Double!
    var postID : String?
    var thumbnailImage: UIImage?
    var imageURLString: String?
    var videoURLString: String?
    var thumbnailString: String?
        
    var cellIndexPath: IndexPath?
    var assetPH: PHAsset?
        
    override init() {}
    
    init(phAsset: PHAsset, thumbnailImg: UIImage, cellIndexPath: IndexPath, timeStamp: Double) {
    //        self.videoURL = videoURL
            self.assetPH = phAsset
            self.thumbnailImage = thumbnailImg

            self.timeStamp = timeStamp
    //        self.caption = caption
    //        self.thumbnailImage = thumbnail

            self.cellIndexPath = cellIndexPath
        }

    init(image: UIImage, phAsset: PHAsset, cellIndexPath: IndexPath, timeStamp: Double) {
            self.image = image
            self.assetPH = phAsset
            self.timeStamp = timeStamp
    //        self.caption = caption

            self.cellIndexPath = cellIndexPath
        }

}
