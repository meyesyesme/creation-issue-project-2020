// this is the device media collection view apge

import UIKit
import Photos
//import SDWebImage

class ExistingMediaVC: UIViewController {

    var existingMediaCollectionView: UICollectionView!
    var latestPhotoAssetsFetched: PHFetchResult<PHAsset>? = nil
    var hasBeenSelectedDict = [0:false]
    var parentCreationVC: CreationVC?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupFakeTopView()
        
        setupFakeMinipreviewView()

        checkPhotoLibraryPermission()
        
        photosPermissionsBtn.tag = 2
        photosPermissionsBtn.addTarget(self, action: #selector(buttonTouchUpInside), for: [.touchUpInside])

    }
    var allAssets = [PHAsset]()
    
    func setupRemainingUIAndFetch() {
        
        self.latestPhotoAssetsFetched = self.fetchLatestMedia(forCount: 0)
        
        let option = PHImageRequestOptions()
        option.isSynchronous = false
        
        let options = PHImageRequestOptions()
//        options.isNetworkAccessAllowed = true
        options.isSynchronous = true
        options.resizeMode = .exact

        let cashManager = PHCachingImageManager()
        self.latestPhotoAssetsFetched?.enumerateObjects({ (phAsset, index, pointer) in
            self.allAssets.append(phAsset)
        })

        DispatchQueue.global(qos: .background).async {
            cashManager.startCachingImages(for: self.allAssets, targetSize: CGSize(width: 138, height: 138), contentMode: .aspectFill, options: options)
        }

        setupExistingMediaCollectionView()

    }
    
    func removePermissionsPg() {
        newPermissionsView.isHidden = true
    }
    
    func checkPhotoLibraryPermission() {
        switch PHPhotoLibrary.authorizationStatus() {
        case .authorized:
            setupRemainingUIAndFetch()
            break;
        //handle authorized status
        case .denied, .restricted :
            setupAndShowPermissionsPage()
            break;
        //handle denied status
        case .notDetermined:
            // ask for permissions
            setupAndShowPermissionsPage()
            break;
        }
    }

        let newPermissionsView = UIView()
        let permissionTitleLabel = UILabel()
        let photosPermissionsBtn = UIButton()

        func setupAndShowPermissionsPage() {
            
            self.view.addSubview(newPermissionsView)

            newPermissionsView.frame = self.view.frame
            newPermissionsView.backgroundColor = UIColor.white.withAlphaComponent(0.7)
            
            newPermissionsView.isUserInteractionEnabled = true
            
            permissionTitleLabel.text = "Please allow the permissions looked in settings make it ok"
            permissionTitleLabel.backgroundColor = .yellow
            
            newPermissionsView.addSubview(permissionTitleLabel)
            permissionTitleLabel.translatesAutoresizingMaskIntoConstraints = false
            
            NSLayoutConstraint.activate([
                permissionTitleLabel.heightAnchor.constraint(equalToConstant: 150), //can change
                permissionTitleLabel.leadingAnchor.constraint(equalTo: newPermissionsView.leadingAnchor, constant: 12),
                permissionTitleLabel.trailingAnchor.constraint(equalTo: newPermissionsView.trailingAnchor, constant: -12), //can change...
                permissionTitleLabel.centerYAnchor.constraint(equalToSystemSpacingBelow: newPermissionsView.centerYAnchor, multiplier: 1.0)
            ])
            
            //For the camera permisisons btn
            photosPermissionsBtn.translatesAutoresizingMaskIntoConstraints = false
            newPermissionsView.addSubview(photosPermissionsBtn)

            NSLayoutConstraint.activate([
                photosPermissionsBtn.heightAnchor.constraint(equalToConstant: 30), //can change
                photosPermissionsBtn.topAnchor.constraint(equalTo: permissionTitleLabel.bottomAnchor, constant: 20),
                photosPermissionsBtn.leadingAnchor.constraint(equalTo: newPermissionsView.leadingAnchor, constant: 12),
                photosPermissionsBtn.trailingAnchor.constraint(equalTo: newPermissionsView.trailingAnchor, constant: -12), //can change...
            ])

            photosPermissionsBtn.setTitle("Allow Photos Access", for: .normal)
            photosPermissionsBtn.setTitleColor(.blue, for: .normal)
            photosPermissionsBtn.backgroundColor = .white
            
        }

    override func viewDidAppear(_ animated: Bool) {

        parentCreationVC?.pageTitle.layoutIfNeeded()

    }
    
    var topViewHeightConstant: CGFloat?
    
    var fakeTopView = UIView()
    
    func setupFakeTopView() {

        fakeTopView.translatesAutoresizingMaskIntoConstraints = false
            
            self.view.addSubview(fakeTopView)
            
            NSLayoutConstraint.activate([
                fakeTopView.heightAnchor.constraint(equalToConstant: topViewHeightConstant!),
                fakeTopView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 0),
                fakeTopView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 0),
                fakeTopView.topAnchor.constraint(equalTo: view.topAnchor, constant: 0),
            ])
            fakeTopView.backgroundColor = .clear
        fakeTopView.isUserInteractionEnabled = false
        
    }
    
    func setupExistingMediaCollectionView() {
        
        let layout = ColumnFlowLayout(
            cellsPerRow: 3,
            minimumInteritemSpacing: 1,
            minimumLineSpacing: 1,
            sectionInset: UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        )
        layout.scrollDirection = .vertical

        let mediaCollectionViewFrame = CGRect()
        existingMediaCollectionView = UICollectionView(frame: mediaCollectionViewFrame, collectionViewLayout: layout)
        
        existingMediaCollectionView.translatesAutoresizingMaskIntoConstraints = false
        
        self.view.addSubview(existingMediaCollectionView)
        
        NSLayoutConstraint.activate([
            existingMediaCollectionView.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 0),
            existingMediaCollectionView.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: 0),
            existingMediaCollectionView.topAnchor.constraint(equalTo: fakeTopView.bottomAnchor, constant: 0),
            existingMediaCollectionView.bottomAnchor.constraint(equalTo: self.fakeMiniPreview.topAnchor, constant: 0),
        ])

        existingMediaCollectionView.register(MediaCollectionVCell.self, forCellWithReuseIdentifier: "CellCo")
        existingMediaCollectionView.delegate = parentCreationVC
        existingMediaCollectionView.dataSource = parentCreationVC
        existingMediaCollectionView.delaysContentTouches = false
        existingMediaCollectionView.alwaysBounceVertical = true
        existingMediaCollectionView.alwaysBounceHorizontal = false
        existingMediaCollectionView.backgroundColor = .black
                                
        existingMediaCollectionView.backgroundColor = .white

    }
    
    var fakeMiniPreview = UIView()
    func setupFakeMinipreviewView() { //this is used for sizing
                fakeMiniPreview.translatesAutoresizingMaskIntoConstraints = false
                fakeMiniPreview.backgroundColor = UIColor.clear
                self.view.addSubview(fakeMiniPreview)
                
                    let safeArea = self.view.safeAreaLayoutGuide

                    NSLayoutConstraint.activate([
                        fakeMiniPreview.heightAnchor.constraint(equalToConstant: 65),
                        fakeMiniPreview.leadingAnchor.constraint(equalTo: safeArea.leadingAnchor, constant: 0),
                        fakeMiniPreview.trailingAnchor.constraint(equalTo: safeArea.trailingAnchor, constant: 0),
                        fakeMiniPreview.bottomAnchor.constraint(equalTo: safeArea.bottomAnchor, constant: 0),
                    ])

    }
        
    func fetchLatestMedia(forCount count: Int?) -> PHFetchResult<PHAsset> {

        // Create fetch options.
//        let options = PHFetchOptions()

        
        // If count limit is specified.

        // Add sortDescriptor so the lastest photos will be returned.
//        let sortDescriptor = NSSortDescriptor(key: "creationDate", ascending: false)
//        options.sortDescriptors = [sortDescriptor]

        // Fetch the photos.
//        let fetchOptions = PHFetchOptions()
//        fetchOptions.sortDescriptors = [NSSortDescriptor(key: "creationDate",ascending: false)]
        
        let fetchOptions = PHFetchOptions()
        fetchOptions.includeAllBurstAssets = false
        fetchOptions.includeHiddenAssets = false
        fetchOptions.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: false)]

        fetchOptions.predicate = NSPredicate(format: "mediaType = %d || mediaType = %d", PHAssetMediaType.image.rawValue, PHAssetMediaType.video.rawValue/*, PHAssetMediaType.unknown.rawValue, PHAssetMediaSubtype.photoScreenshot.rawValue, PHAssetMediaSubtype.photoHDR.rawValue, PHAssetMediaSubtype.photoDepthEffect.rawValue*/)
//        fetchOptions.
//        if let count = count { fetchOptions.fetchLimit = count }

        return PHAsset.fetchAssets(with: fetchOptions)//PHAsset.fetchAssets(options: fetchOptions)
    }

    
//    var allAssets: PHFetchResult<PHAsset>? = nil
//
//    /// Gets and returns all of the PHAsset objects from the photos library. Once this object is initialized and gets these assets, it will set the 'allAssets' PHAsset collection object for any reference after completion.
//    /// - Parameter collection: An optional PHAssetCollection object specifying the album.
//    /// - Parameter includingVideos: A Boolean value indicating whether this method should include videos.
//    /// - Parameters:
//    ///     - assets: An optional array of PHAsset objects found in the specified album.
//    func getAssets(collection: PHAssetCollection? = nil, includingVideos: Bool = true, completionHandler: (_ assets: [PHAsset]?) -> ()) {
//        // MARK: - PHAsset (initialized array of PHAsset objects)
//        var objects = [PHAsset]()
//        objects.removeAll(keepingCapacity: false)
//
//        // MARK: - PHFetchOptions (define options when getting PHAssets in PHAssetCollection)
//        let fetchOptions = PHFetchOptions()
//        fetchOptions.includeAllBurstAssets = false
//        fetchOptions.includeHiddenAssets = false
//        fetchOptions.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: false)]
//
//
//        // MARK: - PHAsset
//        self.allAssets = PHAsset.fetchAssets(with: fetchOptions)
//        self.allAssets!.enumerateObjects({(asset: PHAsset, index: Int, Bool) in
//            objects.append(asset)
//        })
//
//        // Pass the values in the completion handler
//        completionHandler(includingVideos == true ? objects : objects.filter({$0.mediaType != .video}))
//    }


    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
//        existingMediaCollectionView.collectionViewLayout.invalidateLayout() //this updates the layout basically
//        miniPreviewCollectionView.collectionViewLayout.invalidateLayout() ////this updates the layout basically

    }
        
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
        
}


//MARK: - Conversion of TimeInterval
extension TimeInterval {
    func stringFromTimeInterval() -> String {

        let time = NSInteger(self)

        let seconds = time % 60
        let minutes = (time / 60) % 60
        let hours = (time / 3600)

        var formatString = ""
        if hours == 0 {
            if(minutes < 10) {
                formatString = "%2d:%0.2d"
            }else {
                formatString = "%0.2d:%0.2d"
            }
            return String(format: formatString,minutes,seconds)
        }else {
            formatString = "%2d:%0.2d:%0.2d"
            return String(format: formatString,hours,minutes,seconds)
        }
    }

}


extension PHAsset {

    func getURL(completionHandler : @escaping ((_ responseURL : URL?) -> Void)){
        if self.mediaType == .image {
            let options: PHContentEditingInputRequestOptions = PHContentEditingInputRequestOptions()
            options.canHandleAdjustmentData = {(adjustmeta: PHAdjustmentData) -> Bool in
                return true
            }
            self.requestContentEditingInput(with: options, completionHandler: {(contentEditingInput: PHContentEditingInput?, info: [AnyHashable : Any]) -> Void in
                completionHandler(contentEditingInput!.fullSizeImageURL as URL?)
            })
        } else if self.mediaType == .video {
            let options: PHVideoRequestOptions = PHVideoRequestOptions()
            options.version = .original
            PHImageManager.default().requestAVAsset(forVideo: self, options: options, resultHandler: {(asset: AVAsset?, audioMix: AVAudioMix?, info: [AnyHashable : Any]?) -> Void in
                if let urlAsset = asset as? AVURLAsset {
                    let localVideoUrl: URL = urlAsset.url as URL
                    completionHandler(localVideoUrl)
                } else {
                    completionHandler(nil)
                }
            })
        }
    }
}

extension ExistingMediaVC {
        
        @objc func buttonTouchUpInside(_ sender: UIButton) {
            
            switch sender.tag {
            case 1:
                
                break;
            case 2:
                
                switch PHPhotoLibrary.authorizationStatus() {
                case .notDetermined:
                    askForPhotosPermissions()
                    break;
                //handle denied status
                case .restricted, .denied:
                    DispatchQueue.main.async {
                        self.goToAppleSettingsPg()
                    }
                    break;
                case .authorized:
                    break;
                }
                
                break;
            default: ()
            
            break;
            } //end of switch sender tag...
            
        }
    
    func askForPhotosPermissions() {
        
        PHPhotoLibrary.requestAuthorization { status in
            switch status {
            case .authorized:
                DispatchQueue.main.async {
                    self.removePermissionsPg()
                    self.setupRemainingUIAndFetch()
                }
                break;
            // as above
            case .denied, .restricted:
                print("he denied!trollz")
                break;
            // as above
            case .notDetermined:
                //?
                break;
            // won't happen but still
            }
        }

    }
    
    func goToAppleSettingsPg() {
        
        guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else {
            return
        }

        if UIApplication.shared.canOpenURL(settingsUrl) {
            UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                print("Settings opened: \(success)")
            })
        }

    }
        
}

class ColumnFlowLayout: UICollectionViewFlowLayout {

    let cellsPerRow: Int

    init(cellsPerRow: Int, minimumInteritemSpacing: CGFloat = 0, minimumLineSpacing: CGFloat = 0, sectionInset: UIEdgeInsets = .zero) {
        self.cellsPerRow = cellsPerRow
        super.init()

        self.minimumInteritemSpacing = minimumInteritemSpacing
        self.minimumLineSpacing = minimumLineSpacing
        self.sectionInset = sectionInset
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func prepare() {
        super.prepare()

        guard let collectionView1 = collectionView else { print("return in this thing?"); return }
        
        let marginsAndInsets = sectionInset.left + sectionInset.right + collectionView1.safeAreaInsets.left + collectionView1.safeAreaInsets.right + minimumInteritemSpacing * CGFloat(cellsPerRow - 1)
        let itemWidth = ((collectionView1.bounds.size.width - marginsAndInsets) / CGFloat(cellsPerRow)).rounded(.down)
        let itemHeight = CGFloat(208.0)

        itemSize = CGSize(width: itemWidth, height: itemHeight)
    }

    override func invalidationContext(forBoundsChange newBounds: CGRect) -> UICollectionViewLayoutInvalidationContext {
        let context = super.invalidationContext(forBoundsChange: newBounds) as! UICollectionViewFlowLayoutInvalidationContext
        context.invalidateFlowLayoutDelegateMetrics = newBounds.size != collectionView?.bounds.size
        return context
    }

}

class MiniPreviewFlowLayout: UICollectionViewFlowLayout {

    init(minimumInteritemSpacing: CGFloat = 0, minimumLineSpacing: CGFloat = 0, sectionInset: UIEdgeInsets = .zero, itemSize: CGSize = .init(width: 30, height: 50)) {
        super.init()

        self.minimumInteritemSpacing = minimumInteritemSpacing
        self.minimumLineSpacing = minimumLineSpacing
        self.sectionInset = sectionInset
        self.itemSize = itemSize
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func prepare() {
        super.prepare()

        guard let collectionView = collectionView else { return }
    }

    override func invalidationContext(forBoundsChange newBounds: CGRect) -> UICollectionViewLayoutInvalidationContext {
        let context = super.invalidationContext(forBoundsChange: newBounds) as! UICollectionViewFlowLayoutInvalidationContext
        context.invalidateFlowLayoutDelegateMetrics = newBounds.size != collectionView?.bounds.size
        return context
    }

}
